import Link from 'next/link';
import { href } from '@/lib/i18n';

// Header logo: the mark image plus a word mark built from the name and tagline
// in Admin › Settings. To brand the site, replace public/brand/logo-mark.png.
export default function Logo({ lang, label, name, sub }) {
  return (
    <Link href={href(lang, '/')} className="logo" aria-label={label}>
      <img src="/brand/logo-mark.png" alt="" width="40" height="40" className="logo-mark" />
      {(name || sub) && (
        <span className="logo-word latin" aria-hidden="true">
          {name && <span>{name}</span>}
          {sub && <span>{sub}</span>}
        </span>
      )}
    </Link>
  );
}
